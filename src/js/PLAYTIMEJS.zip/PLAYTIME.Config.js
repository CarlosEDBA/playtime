var PLAYTIME = window.PLAYTIME;
var Utils = PLAYTIME.prototype.Utils;
var Config = PLAYTIME.prototype.Config;

Config.DOM.Lalala = document.querySelector('.');

Config.Window = remote.getCurrentWindow();

